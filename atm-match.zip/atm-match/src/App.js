
import './App.css';
import AtmCount from './components/AtmCount';

function App() {
  return (
    <div className="App">
      <AtmCount />
    </div>
  );
}

export default App;
