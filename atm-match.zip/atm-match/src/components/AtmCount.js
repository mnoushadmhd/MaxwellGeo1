import React, { useState } from 'react'
import '../App.css'
function AtmCount() {
    const [num, setNum] = useState()
    const [content, setContent] = useState([])
    const [bool, setBool] = useState(true)

    const showOut = () => {
        let notesContent = []
        let entered = num;
        let remain, thous, fives, twos, ones, fiftys, twentys, tens;
        const lastDigitStr = String(entered).slice(-1);
        const lastDigitNum = Number(lastDigitStr);
        if (lastDigitNum != 0) {
            setBool(false)
            setContent([])
        }
        else {

            if (entered === 1000) {
                fives = 1;
                ones = Math.floor(500 / 100)
                remain = 0;
            }
            if (entered > 1000) {
                thous = Math.floor(entered / 1000)
                remain = entered % 1000

            }
            if (entered < 1000) {
                fives = Math.floor(entered / 500)
                remain = entered % 500
            }
            if (remain >= 500) {
                fives = Math.floor(remain / 500)
                remain = remain % 500
            }
            if (remain >= 200) {
                twos = Math.floor(remain / 200)
                remain = remain % 200
            }
            if (remain >= 100) {
                ones = Math.floor(remain / 100)
                remain = remain % 100
            }
            if (remain >= 50) {
                fiftys = Math.floor(remain / 50)
                remain = remain % 50
            }
            if (remain >= 20) {
                twentys = Math.floor(remain / 20)
                remain = remain % 20
            }
            if (remain >= 10) {
                tens = Math.floor(remain / 10)
                remain = remain % 10
            }
            console.log(thous, fives, fiftys, twentys, tens)
            setBool(true)
        }
        if (thous) {
            let total = thous * 1000;
            let str = `${thous} x 1000 = ${total}`
            notesContent.push(<p key="thous">{str}</p>)

        }
        if (fives) {
            let total = fives * 500;
            let str = `${fives} x 500 = ${total}`
            notesContent.push(<p key="fives">{str}</p>)

        }
        if (twos) {
            let total = twos * 200;
            let str = `${twos} x 200 = ${total}`
            notesContent.push(<p key="twos">{str}</p>)

        }
        if (ones) {
            let total = ones * 100;
            let str = `${ones} x 100 = ${total}`
            notesContent.push(<p key="ones">{str}</p>)

        }
        if (fiftys) {
            let total = fiftys * 50;
            let str = `${fiftys} x 50 = ${total}`
            notesContent.push(<p key="fiftys">{str}</p>)

        }
        if (twentys) {
            let total = twentys * 20;
            let str = `${twentys} x 20 = ${total}`
            notesContent.push(<p key="twentys">{str}</p>)

        }
        if (tens) {
            let total = tens * 10;
            let str = `${tens} x 10 = ${total}`
            notesContent.push(<p key="tens">{str}</p>)

        }
        setContent((content) => notesContent)
    }
    return (
        <>
            <div className='inputSec'>
                <h4>Enter Input</h4>
                <input type="number" onChange={(e) => setNum(e.target.value)} />
                <button onClick={showOut}>Submit</button>
                <div className='outputBox'>
                    <h5>Output :</h5>
                    <div className='outputBody'>
                        {content.length ? content : ""}
                        <p className='invalidText'>{bool ? '' : "Invalid Amount"}</p>
                    </div>
                </div>

            </div>
        </>
    )
}

export default AtmCount