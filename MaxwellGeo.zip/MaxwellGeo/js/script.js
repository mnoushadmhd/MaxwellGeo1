$(document).ready(function () {
    const url = 'https://api.github.com/users';
    let avatarContent = ''
    getData()
    console.log("first")
    if (screen.width <= 767) {
        $('.myDrawer').addClass("offcanvas")
    }
    $(window).on('resize', function () {
        if (screen.width <= 767) {
            $('.myDrawer').addClass("offcanvas")
        }
        else {
            $('.myDrawer').removeClass("offcanvas")
        }
    })
    async function getData() {

        const getUsers = await fetch(url).then(res => res.json())
        for (i = 0; i < 10; i++) {
            let name = getUsers[i].login.slice(0, 5)

            avatarContent = avatarContent + `
                                    <div class="avatarBox">
                            <div class="avatarImage">
                                <img src=${getUsers[i].avatar_url} alt="">
                            </div>
                            <div class="avatarName">
                                <p>${name}</p>
                            </div>
                        </div>

            `
        }
        $('.profilePic img').attr("src", getUsers[11].avatar_url)
        $('.avatarContainer').html(avatarContent)
    }
    // --chart------------
    var chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,

        axisX: {
            valueFormatString: " MMM",
            crosshair: {
                enabled: true,
                snapToDataPoint: true
            }
        },
        axisY: {
            valueFormatString: "###K",
            crosshair: {
                enabled: true,
                snapToDataPoint: true,
                labelFormatter: function (e) {
                    return CanvasJS.formatNumber(e.value, "###K");
                }
            }
        },
        data: [{
            type: "area",
            xValueFormatString: " MMM",
            yValueFormatString: "###k",
            dataPoints: [
                { label: "JAN", y: 100 },
                { label: "FEB", y: 200 },
                { label: "MAR", y: 180 },
                { label: "APR", y: 90 },
                { label: "MAY", y: 250 },
                { label: "JUN", y: 220 },
                { label: "JUL", y: 360 },
                { label: "AUG", y: 320 },
                { label: "SEP", y: 400 },
                { label: "OCT", y: 280 },
                { label: "NOV", y: 300 },
                { label: "DEC", y: 330 }

            ]
        }]
    });
    chart.render();
    $('#dropdownMenuButton').on('click', function () {
        $(this).next('.dropdown-menu').toggle()
    })
    const specifiedElement = document.getElementById('dropdownMenuButton')


    document.addEventListener('click', event => {
        const isClickInside = specifiedElement.contains(event.target)

        if (!isClickInside) {
            $('.dropMenu').hide()
        }
    })
    $('.post-inner').on('click', function () {
        $('.postsList').slideToggle();
        if ($(this).hasClass("open")) {
            $('.postIcon').attr("src", "images/icons/chevron-arrow-down.png")
            $(this).removeClass("open")
        }
        else {
            $('.postIcon').attr("src", "images/icons/right-chevron.png")
            $(this).addClass("open")
        }

    })
    $('.favourite-inner').on('click', function () {
        $('.favoritesList').slideToggle();
        if ($(this).hasClass("open")) {
            $('.favIcon').attr("src", "images/icons/chevron-arrow-down.png")
            $(this).removeClass("open")
        }
        else {
            $('.favIcon').attr("src", "images/icons/right-chevron.png")
            $(this).addClass("open")
        }
    })
    $('.imageGallery img').on("click", function () {
        $('.modalBox').addClass("active")
        $('#overlay').addClass("active")
        let url = $(this).attr("src")
        $('.imageBody').attr("src", url)
    })
    $('.modalHead p ').on("click", function () {
        $('.modalBox').removeClass("active")
        $('#overlay').removeClass("active")
    })
    if (screen.width > 1500) {
        $('.homeWrapper').addClass("container")
        $('.homeWrapper').css("margin", "auto")
    }
    $(window).on('resize', function () {
        if (screen.width > 1500) {
            $('.homeWrapper').addClass("container")
            $('.homeWrapper').css("margin", "auto")
        }
        else {
            $('.homeWrapper').removeClass("container")
            if (screen.width < 768) {
                $('.homeWrapper').css("margin", "0 20px")
            }
            else {
                $('.homeWrapper').css("margin", "0 40px")
            }
        }
    })
    $('.videoClose').on('click', function () {
        $('.photoAdd').hide()
    })
    $('.photoClose').on('click', function () {
        $('.videoAdd').hide()
    })


})